# API START with user, authentication, authorization, MVC

Built using modern technologies: node.js, express, mongoDB, mongoose and friends 😁
