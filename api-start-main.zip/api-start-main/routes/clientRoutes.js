const express = require('express');
const clientController = require('../controllers/clientController');
const authController = require('../controllers/authController');

const router = express.Router({ mergeParams: true });

router.use(authController.protect);

router
  .route('/')
  .get(clientController.getAllClients)
  .post(authController.restrictTo('admin'), clientController.createClient);

router
  .route('/:id')
  .get(clientController.getClient)
  .patch(
    authController.restrictTo('manager', 'admin'),
    clientController.updateClient
  )
  .delete(
    authController.restrictTo('manager', 'admin'),
    clientController.deleteClient
  );

module.exports = router;
