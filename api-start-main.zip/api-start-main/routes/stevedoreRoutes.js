const express = require('express');
const stevedoreController = require('../controllers/stevedoreController');
const authController = require('../controllers/authController');

const router = express.Router({ mergeParams: true });

router.use(authController.protect);

router
  .route('/')
  .get(stevedoreController.getAllStevedores)
  .post(
    authController.restrictTo('admin'),
    stevedoreController.createStevedore
  );

router
  .route('/:id')
  .get(stevedoreController.getStevedore)
  .patch(
    authController.restrictTo('manager', 'admin'),
    stevedoreController.updateStevedore
  )
  .delete(
    authController.restrictTo('manager', 'admin'),
    stevedoreController.deleteStevedore
  );

module.exports = router;
