const Stevedore = require('../models/stevedoreModel');
const factory = require('./handlerFactory');
// const catchAsync = require('./../utils/catchAsync');


exports.getAllStevedores = factory.getAll(Stevedore);
exports.getStevedore = factory.getOne(Stevedore);
exports.createStevedore = factory.createOne(Stevedore);

exports.updateStevedore = factory.updateOne(Stevedore);
exports.deleteStevedore = factory.deleteOne(Stevedore);
