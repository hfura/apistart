const Client = require('../models/clientModel');
const factory = require('./handlerFactory');
// const catchAsync = require('./../utils/catchAsync');


exports.getAllClients = factory.getAll(Client);
exports.getClient = factory.getOne(Client);
exports.createClient = factory.createOne(Client);

//verify if user is ower, admin or manager before the following
exports.updateClient = factory.updateOne(Client);
exports.deleteClient = factory.deleteOne(Client);
