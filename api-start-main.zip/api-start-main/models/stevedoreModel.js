const mongoose = require('mongoose');

const stevedoreSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'Name can not be empty!'],
    },
    company: {
      type: mongoose.Schema.ObjectId,
      ref: 'Client',
      required: [true, 'Stevedore must belong to a company.'],
    },
    qrcode: String,
  },
  {
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
    timestamps: true,
  }
);




const Stevedore = mongoose.model('Stevedore', stevedoreSchema);

module.exports = Stevedore;
