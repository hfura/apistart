const mongoose = require('mongoose');

const clientSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'Name can not be empty!'],
    },
    vat: {
      type: String,
      required: [true, 'VAT can not be empty!'],
      unique: true,
    },

  },
  {
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
    timestamps: true,
  }
);


const Client = mongoose.model('Client', clientSchema);

module.exports = Client;
